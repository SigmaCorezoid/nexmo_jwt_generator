(ns usercode.usercode)

(defn handle [data]
   (assoc data :hello "Hello world!"))
