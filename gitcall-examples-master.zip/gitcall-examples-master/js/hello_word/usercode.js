module.exports = (data) => {
    data.hello = "Hello World!";

    return data;
};