
def handle(data):
    data["hello"] = "Hello world!"
    return data
