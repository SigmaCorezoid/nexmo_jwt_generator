<?php

function handle($data) {
    $data['hello'] = "Hello world!";

    return $data;
}